﻿using System;
using RestSharp;

namespace csharpclient
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new RestClient("http://192.168.50.86.:5000/predict");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "{\"query\":\"Water found leaking at the corridor. I have report 2 weeks ago but no action\"\r\n}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);
        }
    }
}
